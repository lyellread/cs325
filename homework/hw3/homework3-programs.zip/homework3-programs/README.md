## Running this code ##

`python3 programname [data.txt]`


